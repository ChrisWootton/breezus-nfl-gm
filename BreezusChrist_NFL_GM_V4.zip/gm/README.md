# BreezusChrist NFL GM V4

A mobile-first Sleeper dynasty GM dashboard with a Cloudflare Pages API proxy.

## Important deployment change

V4 contains a `/functions/api/sleeper.js` Pages Function. **Do not use Cloudflare Pages Direct Upload.** Cloudflare Pages Functions require Git integration or Wrangler deployment.

### GitHub + Cloudflare Pages

1. Create a new GitHub repository.
2. Upload the contents of this ZIP to the repository root. Keep `index.html` at the root and keep the `functions` folder at the root.
3. In Cloudflare: Workers & Pages → Create application → Pages → Connect to Git.
4. Select the GitHub repository.
5. Framework preset: **None**.
6. Build command: leave blank (or `exit 0`).
7. Build output directory: `.`
8. Deploy.

The live site calls `/api/sleeper`, and the Cloudflare Function forwards requests to Sleeper's public read-only API.

## Pre-filled settings
League ID: `1312047300213739520`
Username: `Breezuschrist`

## Test
Open your deployed site, go to Settings if needed, then press **RUN MY NFL GM**. The status card should report `LIVE GM RUN COMPLETE`.
